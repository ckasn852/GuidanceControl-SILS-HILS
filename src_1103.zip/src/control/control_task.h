#ifndef CONTROL_TASK_H
#define CONTROL_TASK_H

extern float velocity_out[6];
void control_task(); // control_task �Լ� ����

#endif
