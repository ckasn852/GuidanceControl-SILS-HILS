/*
 * Copyright (C) 2017 - 2022 Xilinx, Inc.
 * Copyright (C) 2022 - 2023 Advanced Micro Devices, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include <sleep.h>
#include "netif/xadapter.h"
#include "platform_config.h"
#include "xil_printf.h"
#include "lwip/init.h"
#include "lwip/inet.h" // sockaddr_in�� ���� �߰�
#include <string.h> // memset�� ���� �߰�

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"     // Mutex ����� ���� �߰�

#include "udp_task.h"
#include "servo_task.h"
#include "control_task.h" // �ű� ���� �½�ũ ��� �߰�

#ifdef XPS_BOARD_ZCU102
#if defined(XPAR_XIICPS_0_DEVICE_ID) || defined(XPAR_XIICPS_0_BASEADDR)
int IicPhyReset(void);
#endif
#endif

void print_app_header();
void start_application();
int udp_thread();

#define THREAD_STACKSIZE 1024


#define SERVO_TASK_PRIORITY   ( tskIDLE_PRIORITY + 3 )
#define CONTROL_TASK_PRIORITY ( tskIDLE_PRIORITY + 2 )
#define UDP_TASK_PRIORITY     ( tskIDLE_PRIORITY + 1 )


// ���� �ڵ� �� ���� ����
QueueHandle_t xAngleQueue = NULL;
SemaphoreHandle_t g_hils_data_mutex = NULL;
HILS_Data_t g_latest_hils_data = {0.0f, 0.0f, 0.0f, 0.0f};

// SILS �ǵ��� ���� ���� ����
SemaphoreHandle_t g_sils_mutex = NULL;
int g_sock = -1;
struct sockaddr_in g_client_addr;
socklen_t g_client_addr_len = sizeof(g_client_addr);


int main()
{
    xil_printf("--- Main Application Started (Decoupled HILS + SILS) ---\r\n");

    // 1. ť(Queue) ����
    xAngleQueue = xQueueCreate(10, sizeof(ServoCommand_t));
    if (xAngleQueue == NULL) {
        xil_printf("FATAL ERROR: Failed to create xAngleQueue!\r\n");
        while(1);
    }
    xil_printf("xAngleQueue created successfully.\r\n");


    // 2. Mutex ���� (�����Ϳ�)
    g_hils_data_mutex = xSemaphoreCreateMutex();
    if (g_hils_data_mutex == NULL) {
        xil_printf("FATAL ERROR: Failed to create g_hils_data_mutex!\r\n");
        while(1);
    }
    xil_printf("g_hils_data_mutex created successfully.\r\n");

    // 3. Mutex ���� (SILS �ǵ���)
    g_sils_mutex = xSemaphoreCreateMutex();
    if (g_sils_mutex == NULL) {
        xil_printf("FATAL ERROR: Failed to create g_sils_mutex!\r\n");
        while(1);
    }
    xil_printf("g_sils_mutex created successfully.\r\n");

    // 4. ���� SILS ���� �ʱ�ȭ
    memset(&g_client_addr, 0, sizeof(g_client_addr));
    g_sock = -1;

    // 5. �½�ũ ���� (�� 3��)

    // �½�ũ 1: vServoControlTask (���� ����̹�)
    xTaskCreate(vServoControlTask,
                "ServoDriver",
                configMINIMAL_STACK_SIZE + 1024,
                NULL,
                SERVO_TASK_PRIORITY,
                NULL);

    // �½�ũ 2: vControlLoopTask (���� ����)
    xTaskCreate(vControlLoopTask,
                "ControlLoop",
                configMINIMAL_STACK_SIZE + 2048,
                NULL,
                CONTROL_TASK_PRIORITY,
                NULL);

    // �½�ũ 3: udp_thread (��Ʈ��ũ/������ ����)
    xTaskCreate((void (*)(void*))udp_thread,
                "UdpTask",
                configMINIMAL_STACK_SIZE + 2048,
                NULL,
                UDP_TASK_PRIORITY,
                NULL);

    xil_printf("All 3 tasks (UDP, Control, Servo) created.\r\n");

    // 6. FreeRTOS �����ٷ� ����
    xil_printf("Starting FreeRTOS Scheduler...\r\n");
    vTaskStartScheduler();

    while(1) {
    }

    return 0;
}
