#ifndef __IBVS_H_
#define __IBVS_H_

void calculate_target_coords_error(float target_x, float target_y);
int IBVS_calculation(float* velocity_out, float x, float y);

#endif /*__IBVS_H_*/
