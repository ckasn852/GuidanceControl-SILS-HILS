/*
 * Copyright (C) 2017 - 2019 Xilinx, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include "udp_task.h"

#include <stdio.h>
#include <string.h>
#include <sleep.h>
#include "netif/xadapter.h"
#include "platform_config.h"
#include "xil_printf.h"
#include "lwip/init.h"
#include "lwip/inet.h"

#include "FreeRTOS.h"
#include "control_task.h"

#define DEFAULT_IP_ADDRESS "192.168.1.10"
#define DEFAULT_IP_MASK "255.255.255.0"
#define DEFAULT_GW_ADDRESS "192.168.1.1"
#define MAX_BUFFER_LEN 256
extern struct netif server_netif;

struct netif server_netif;
static int complete_nw_thread;
#define THREAD_STACKSIZE 1024


#ifdef XPS_BOARD_ZCU102
#if defined(XPAR_XIICPS_0_DEVICE_ID) || defined(XPAR_XIICPS_0_BASEADDR)
int IicPhyReset(void);
#endif
#endif


static void print_ip(char *msg, ip_addr_t *ip)
{
	xil_printf(msg);
	xil_printf("%d.%d.%d.%d\n\r", ip4_addr1(ip), ip4_addr2(ip),
				ip4_addr3(ip), ip4_addr4(ip));
}

static void print_ip_settings(ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw)
{
	print_ip("Board IP:       ", ip);
	print_ip("Netmask :       ", mask);
	print_ip("Gateway :       ", gw);
}

static void assign_default_ip(ip_addr_t *ip, ip_addr_t *mask, ip_addr_t *gw)
{
	int err;

	xil_printf("Configuring default IP %s \r\n", DEFAULT_IP_ADDRESS);

	err = inet_aton(DEFAULT_IP_ADDRESS, ip);
	if(!err)
		xil_printf("Invalid default IP address: %d\r\n", err);

	err = inet_aton(DEFAULT_IP_MASK, mask);
	if(!err)
		xil_printf("Invalid default IP MASK: %d\r\n", err);

	err = inet_aton(DEFAULT_GW_ADDRESS, gw);
	if(!err)
		xil_printf("Invalid default gateway address: %d\r\n", err);
}


void network_thread(void *p)
{
	u8_t mac_ethernet_address[] = { 0x00, 0x0a, 0x35, 0x00, 0x01, 0x02 };

	if (!xemac_add(&server_netif, NULL, NULL, NULL, mac_ethernet_address,
		PLATFORM_EMAC_BASEADDR)) {
		xil_printf("Error adding N/W interface\r\n");
		return;
	}

	netif_set_default(&server_netif);

	netif_set_up(&server_netif);

	sys_thread_new("xemacif_input_thread",
			(void(*)(void*))xemacif_input_thread, &server_netif,
			THREAD_STACKSIZE, DEFAULT_THREAD_PRIO);

	complete_nw_thread = 1;

	vTaskDelete(NULL);
}


int udp_thread()
{

#ifdef XPS_BOARD_ZCU102
	IicPhyReset();
#endif
	xil_printf("\n\r\n\r");
	xil_printf("Zynq board Booting successfully\r\n");
	xil_printf("-----lwIP Socket Mode UDP Client Application------\r\n");

	lwip_init();

	sys_thread_new("nw_thread", network_thread, NULL,
			THREAD_STACKSIZE, DEFAULT_THREAD_PRIO);

	while(!complete_nw_thread)
		usleep(50);


	assign_default_ip(&(server_netif.ip_addr), &(server_netif.netmask),
				&(server_netif.gw));

	print_ip_settings(&(server_netif.ip_addr), &(server_netif.netmask),
				&(server_netif.gw));
	xil_printf("\r\n");

	print_app_header();
	xil_printf("\r\n");

	start_application();

	vTaskDelete(NULL);
	return 0;
}


void print_app_header(void)
{
    xil_printf("------------------------------------------------------\r\n");
    xil_printf("         UDP String Parser/Echo Application\r\n");
    xil_printf("------------------------------------------------------\r\n");
    xil_printf("Listening on port %d for formatted string data\r\n", UDP_CONN_PORT);
    xil_printf("Waiting for data from client...\r\n");
}

void start_application(void)
{
	    struct sockaddr_in server_addr;
	    int n;
	    char recv_buffer[MAX_BUFFER_LEN];

        // recvfrom이 사용할 '로컬' 주소 변수
        struct sockaddr_in local_client_addr;
        socklen_t local_client_addr_len = sizeof(local_client_addr);

	    if ((g_sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
	        xil_printf("Error: Could not create socket\r\n");
	        return;
	    }

	    memset(&server_addr, 0, sizeof(server_addr));
	    server_addr.sin_family = AF_INET;
	    server_addr.sin_port = htons(UDP_CONN_PORT);
	    server_addr.sin_addr.s_addr = INADDR_ANY;

	    if (bind(g_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
	        xil_printf("Error: Failed to bind socket\r\n");
	        close(g_sock);
	        return;
	    }

        xil_printf("UDP Task: Waiting for data...\r\n");

	    while (1) {
            // 공용 g_client_addr 대신 '로컬' 변수에 주소를 받음
	        n = recvfrom(g_sock, recv_buffer, sizeof(recv_buffer) - 1, 0,
	                     (struct sockaddr *)&local_client_addr, &local_client_addr_len);

	        if (n < 0) {
	            xil_printf("Error: recvfrom failed\r\n");
	            continue;
	        }

	        recv_buffer[n] = '\0';

	        float p_val, y_val ;
	        float x_coord, y_coord;

	        int items_scanned = sscanf(recv_buffer, "P: %f Y: %f x: %f y: %f",
	                                   &p_val, &y_val, &x_coord, &y_coord);

	        if (items_scanned == 4) {

	            if (xSemaphoreTake(g_hils_data_mutex, (TickType_t)10) == pdTRUE)
	            {
	                g_latest_hils_data.p_val = p_val;
	                g_latest_hils_data.y_val = y_val;
	                g_latest_hils_data.x_coord = x_coord;
	                g_latest_hils_data.y_coord = y_coord;
	                xSemaphoreGive(g_hils_data_mutex);
	            } else {
	                xil_printf("UDP Task: Failed to get g_hils_data_mutex.\r\n");
	            }

                // SILS 주소 업데이트 (Mutex 보호)
                // 로컬 주소 -> 공용 주소로 안전하게 복사
                if (xSemaphoreTake(g_sils_mutex, (TickType_t)10) == pdTRUE)
                {
                    memcpy(&g_client_addr, &local_client_addr, sizeof(local_client_addr));
                    g_client_addr_len = local_client_addr_len;
                    xSemaphoreGive(g_sils_mutex);
                } else {
                    xil_printf("UDP Task: Failed to get g_sils_mutex.\r\n");
                }

	        } else {
	            xil_printf("Warning: Received string does not match format: %s\r\n", recv_buffer);
	        }
	    }

	    close(g_sock);
}
