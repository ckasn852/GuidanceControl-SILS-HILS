/*
 * Copyright (C) 2017 - 2022 Xilinx, Inc.
 * Copyright (C) 2022 - 2023 Advanced Micro Devices, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include <sleep.h>
#include "netif/xadapter.h"
#include "platform_config.h"
#include "xil_printf.h"
#include "lwip/init.h"
#include "lwip/inet.h"

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

#include "udp_task.h"
#include "servo_task.h"

#ifdef XPS_BOARD_ZCU102
#if defined(XPAR_XIICPS_0_DEVICE_ID) || defined(XPAR_XIICPS_0_BASEADDR)
int IicPhyReset(void);
#endif
#endif

void print_app_header();
void start_application();
int udp_thread();

#define THREAD_STACKSIZE 1024


#define UDP_TASK_PRIORITY   ( tskIDLE_PRIORITY + 2 )
#define SERVO_TASK_PRIORITY ( tskIDLE_PRIORITY + 3 )


QueueHandle_t xAngleQueue = NULL;


int main()
{
    xil_printf("--- Main Application Started (Simple 1-Queue System) ---\r\n");

    // 1. ť(Queue) ����

    // [������ ť] udp_thread -> vServoControlTask
    xAngleQueue = xQueueCreate(10, sizeof(ServoCommand_t));

    // [����] xTargetAngleQueue ���� ����
    // xTargetAngleQueue = xQueueCreate(10, sizeof(ServoCommand_t));

    if (xAngleQueue == NULL) { // [����] 1�� ť�� Ȯ��
        xil_printf("FATAL ERROR: Failed to create xAngleQueue!\r\n");
        while(1);
    }
    xil_printf("xAngleQueue created successfully.\r\n");


    // 2. �½�ũ ���� (2���� ����)

    // �½�ũ 1: vServoControlTask (�������)
    // �켱���� 2 (����)
    xTaskCreate(vServoControlTask,
                "ServoDriver",
                configMINIMAL_STACK_SIZE + 1024,
                NULL,
                tskIDLE_PRIORITY + 2,
                NULL);

    // [����] vMotionPlannerTask ���� ����
    // xTaskCreate(vMotionPlannerTask, ...);

    // �½�ũ 2: udp_thread (��������)
    // �켱���� 1 (����)
    xTaskCreate((void (*)(void*))udp_thread,
                "GuidanceTask",
                configMINIMAL_STACK_SIZE + 2048,
                NULL,
                tskIDLE_PRIORITY + 1,
                NULL);

    xil_printf("All 2 tasks (Guidance, Driver) created.\r\n");

    // 3. FreeRTOS �����ٷ� ����
    xil_printf("Starting FreeRTOS Scheduler...\r\n");
    vTaskStartScheduler();

    while(1) {
    }

    return 0;
}
