/*
 * Copyright (C) 2017 - 2022 Xilinx, Inc.
 * Copyright (C) 2022 - 2023 Advanced Micro Devices, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 */

#include <sleep.h>
#include "netif/xadapter.h"
#include "xil_printf.h"
#include "lwip/init.h"
#include "lwip/inet.h"
#include "rx/rx_task.h"
#include "tx/tx_task.h"
#include "control/control_task.h"
#include "network_init/network_bootstrap.h"

// FreeRTOS
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "control/control_queue.h"
#include "motor/motor_driver_task.h"
#include "motor/motor_driver_task.h"


#define TASK_STACKSIZE  1024

SemaphoreHandle_t networkInitMutex;
SemaphoreHandle_t printMutex;

QueueHandle_t xAngleQueue = NULL;



static void network_init_task(void *arg)
{
    (void)arg; // �� ���� ��� ����

    if (xSemaphoreTake(networkInitMutex, portMAX_DELAY) != pdTRUE) {
        xil_printf("network_init_task: mutex take fail\r\n");
        vTaskDelete(NULL);
        return;
    }

    // Zynq ���� ��Ʈ��ũ ���� �ʱ�ȭ
    network_bootstrap();

    // �ʱ�ȭ �Ϸ� -> ���� rx_task ���� �ֵ��� ��Ʈ��ũ ����ص� ��
    xSemaphoreGive(networkInitMutex);

    // ���� �ʱ�ȭ �Ǹ� �½�ũ ����
    vTaskDelete(NULL);
}

int main()
{
    xil_printf("\n\r\n\r");
    xil_printf("Zynq board Boot Successful\r\n");
    xil_printf("-----lwIP Socket Mode UDP Client Application------\r\n");

    networkInitMutex = xSemaphoreCreateMutex();		// ��Ʈ��ũ �ʱ�ȭ ���ؽ� ����
    printMutex = xSemaphoreCreateMutex();			// ����Ʈ ���ؽ� ����

    // ���� ������ ť �ʱ�ȭ
    control_queue_init();

    xAngleQueue = xQueueCreate(10, sizeof(ServoCommand_t));
        if (xAngleQueue == NULL) {
            xil_printf("FATAL: Failed to create xAngleQueue\r\n");
            while(1);
        }



    // ��Ʈ��ũ �ʱ�ȭ �½�ũ ����
    xTaskCreate(network_init_task,
				"network_init_task",
				TASK_STACKSIZE,
				NULL,
				tskIDLE_PRIORITY+5,
				NULL);

    xTaskCreate(vMotorDriverTask,
    				"motor_driver_task",
    				TASK_STACKSIZE,
    				NULL,
    				tskIDLE_PRIORITY+4,
    				NULL);

    // ���� �½�ũ ����
    	xTaskCreate(control_task,
    			"control_task",
    				TASK_STACKSIZE,
    				NULL,
    				tskIDLE_PRIORITY+3,
    				NULL);

        // ���� �½�ũ ����
    	xTaskCreate(rx_task,
    				"rx_task",
    				TASK_STACKSIZE,
    				NULL,
    				tskIDLE_PRIORITY+2,
    				NULL);


        // �۽� �½�ũ ����
        xTaskCreate(tx_task,
    				"tx_task",
    				TASK_STACKSIZE,
    				NULL,
    				tskIDLE_PRIORITY+1,
    				NULL);

    	//scheduling ����
    	vTaskStartScheduler();
    	while(1);
    	return 0;
}
