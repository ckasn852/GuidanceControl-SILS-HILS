GuidanceControl-SILS-HILS
Simulation and HILS platform for missile guidance and control system developed during LIG Nex1 Embedded SW Bootcamp.